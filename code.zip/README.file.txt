To run the file: 
- Add the testing and training data in the same directory as the code file (main.py)
- All the packages where installed with conda, so you can use 'conda install' to get all the packages 
- Then you can either run it from the command promt using 'python main.py'
- Or run it from an IDE

Thats it.